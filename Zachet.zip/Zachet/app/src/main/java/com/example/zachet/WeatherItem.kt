package com.example.zachet
data class WeatherItem(
    val city: String,
    val date: String,
    val temp: Double
)