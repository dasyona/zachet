package com.example.zachet

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class WeatherAdapter(
    private val items: List<WeatherItem>,
    private val onItemClick: (WeatherItem) -> Unit // Это для перехода
) : RecyclerView.Adapter<WeatherAdapter.ViewHolder>() {


    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val city: TextView = view.findViewById(R.id.tvItemCity)
        val date: TextView = view.findViewById(R.id.tvItemDate)
    }

    // Создаем пустую строку
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_weather, parent, false)
        return ViewHolder(view)
    }

    // Заполняем строку данными
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.city.text = item.city
        holder.date.text = "${item.date} - ${item.temp}°C"

        // Обработка клика
        holder.itemView.setOnClickListener {
            onItemClick(item)
        }
    }

    override fun getItemCount() = items.size
}